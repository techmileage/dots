## How to contribute

Just make sure to have updated and run the tests:

    python -m unittest test_alias-tips

Then open a pull-request.


## Credits

Credits for contributions:

- [jeffreytse](https://github.com/jeffreytse)
- [m42e](https://github.com/m42e)
- [pradyunsg](https://github.com/pradyunsg)
- [tomprince](https://github.com/tomprince)
- [unixorn](https://github.com/unixorn)
